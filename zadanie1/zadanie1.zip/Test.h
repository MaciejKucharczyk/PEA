//
// Created by Maciej on 05.11.2022.
//

#ifndef PEA_TEST_H
#define PEA_TEST_H

#include <vector>

using namespace std;


class Test {
public:
    void test_BF();
    void test_BB();
    void test_test();
};


#endif //PEA_TEST_H
