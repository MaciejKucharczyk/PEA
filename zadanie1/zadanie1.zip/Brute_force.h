//
// Created by Maciej on 29.10.2022.
//

#ifndef PEA_BRUTE_FORCE_H
#define PEA_BRUTE_FORCE_H

#include <vector>

using namespace std;

class Brute_force {
public:
    static void shortest_path(vector<vector<int>>, int);
};


#endif //PEA_BRUTE_FORCE_H
